import java.util.Scanner;

public class Practice1 {

	public static void main(String[] args) {
		
		// 홀짝 프로그램
		Scanner sc = new Scanner(System.in);
		/*System.out.print("숫자를 입력하세요 : ");
		int i = sc.nextInt();
		
		String a = ((i % 2) == 0) ? "짝수" : "홀수";
		System.out.println(a);*/
		
		
		
		
		
		
		
		
		
		
	}
}
