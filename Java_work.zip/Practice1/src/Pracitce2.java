
public class Pracitce2 {

	final static int N = 15;
	
	public static void main(String[] args) {

		/*String a = "I Love You";
		if(a.contains("Love"))
		{
			 // 포함하는 경우 실행
			System.out.println("Me Too");
		}
		else
		{
			// 포함하지 않는 경우 실행
			System.out.println("I Hate You");
		}*/
		
		
		/*int score = 95;
		
		if (score >= 90)
		{
			System.out.println("A+ 입니다");
		}
		else if (score >= 90)
		{
			System.out.println("B+ 입니다");
		}
		else if (score >= 90)
		{
			System.out.println("C+ 입니다");
		}
		else
		{
			System.out.println("F 입니다");
		}*/
		
		//String a = "Man";
		//int b = 0;
		
		// 자바는 String을 비교할 때 equal()을 이용
		/*if (a.equals("Man"))
		{
			System.out.println("남자입니다");
		}
		else
		{
			System.out.println("남자가 아닙니다");
		}
		if (b == 3)
		{
			System.out.println("b는 3입니다");
		}
		else
		{
			System.out.println("b는 3이 아닙니다");
		}
		if (a.equalsIgnoreCase("man") && b == 0)
		{
			System.out.println("참입니다");
		}
		else
		{
			System.out.println("거짓입니다");
		}*/
		
		/*int i = 1, sum = 0;
		while (i <= 1000)
		{
			sum += i++;
		}
		System.out.println("1부터 1000까지의 합은 " + sum + "입니다");*/
		
		// x^2 + y^2 = z^2
		/*for(int i = -N; i <= N; i++)
		{
			for(int j = -N; j <= N; j ++)
			{
				if(i * i + j * j <= N * N)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();
		}*/
		
		
		
		

	}

}
