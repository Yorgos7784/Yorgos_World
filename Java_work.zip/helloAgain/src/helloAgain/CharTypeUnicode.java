package helloAgain;

public class CharTypeUnicode {

	public static void main(String[] args) {
		/*char ch1 = '헐';
		char ch2 = '확';
		char ch3 = 54736;  // 문자 '헐'의 유니코드 값
		char ch4 = 54869;  // 문자 '확'의 유니코드 값
		char ch5 = 0xD5D0;
		char ch6 = 0xD655;
		
		System.out.println(ch1 + " " + ch2);
		System.out.println(ch3 + " " + ch4);
		System.out.println(ch5 + " " + ch6);
		System.out.println("");
		
		ch1 = 0x3041;
		ch2 = 0x3051;
		ch3 = 0x3061;
		ch4 = 0x3071;
		System.out.println(ch1 + " " + ch2 + " " + ch3 + " " + ch4);
		System.out.println("");
		
		ch1 = 0x3043;
		ch2 = 0x3053;
		ch3 = 0x3063;
		ch4 = 0x3073;
		System.out.println(ch1 + " " + ch2 + " " + ch3 + " " + ch4);
		System.out.println("");*/
		
		
		/*boolean b1 = true;
		boolean b2 = false;
		System.out.println(b1);
		System.out.println(b2);
		
		int num1 = 10;
		int num2 = 20;
		System.out.println(num1 < num2);
		System.out.println(num1 > num2);*/
	
		/*final int MAX_SIZE = 100;
		final char CONST_CHAR = '상';
		final int CONST_ASSIGNED;
		CONST_ASSIGNED = 12;
		
		System.out.println("상수1 : " + MAX_SIZE);
		System.out.println("상수2 : " + CONST_CHAR);
		System.out.println("상수3 : " + CONST_ASSIGNED);*/
		
	
	}

}
