package helloAgain;

public class Hello {

	public static void main(String[] args) {
		
		System.out.println("저는 어마무시한 코드를 쓸 수 있지만 여백이 부족하여\n여기까지만 쓰겠습니다");
	}

}
