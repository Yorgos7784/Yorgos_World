
public class Function1 {

	public static void main(String[] args) {

		

	}

}
