import java.util.Scanner;

public class InputPractice {

	public static void main(String[] args) {
		
		/*Scanner sc = new Scanner(System.in);
		
		System.out.print("국어점수를 입력하세요 : ");
		int KOREAN = sc.nextInt();
		System.out.print("영어점수를 입력하세요 : ");
		int ENGLISH = sc.nextInt();
		System.out.print("수학점수를 입력하세요 : ");
		int MATH = sc.nextInt();
		System.out.print("과학점수를 입력하세요 : ");
		int SCIEN = sc.nextInt();
		System.out.println("-----------------");*/
		/*System.out.printf("\n국어의 점수는 : %d점 입니다\n", KOREAN);
		System.out.printf("엉어의 점수는 : %d점 입니다\n", ENGLISH);
		System.out.printf("수학의 점수는 : %d점 입니다\n", MATH);
		System.out.printf("과학의 점수는 : %d점 입니다\n", SCIEN);*/
		/*System.out.println("\n국어의 점수는 " + KOREAN + "점 입니다");
		System.out.println("영어의 점수는 " + ENGLISH + "점 입니다");
		System.out.println("수학의 점수는 " + MATH + "점 입니다");
		System.out.println("과학의 점수는 " + SCIEN + "점 입니다");
		System.out.println("\n모든 점수의 평균은 " + ((KOREAN + ENGLISH + MATH + SCIEN) / 4.0) + "입니다");*/
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("국어점수를 입력하세요 : ");
		int a = sc.nextInt();
		System.out.println("국어점수를 입력하세요 : ");
		int b = sc.nextInt();
		System.out.println("국어점수를 입력하세요 : ");
		int c = sc.nextInt();
		System.out.println("국어점수를 입력하세요 : ");
		int d = sc.nextInt();

	}

}
