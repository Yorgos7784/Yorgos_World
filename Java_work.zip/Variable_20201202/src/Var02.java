
public class Var02 {

	public static void main(String[] args) {

		byte num = 'A';
		short char1 = 'B';
		char char2 = 66;
		long num2 = 9876543210L;

		System.out.println("num : " + num);
		System.out.println("char1 : " + char1);
		System.out.println("char2 : " + char2);
		System.out.println("num2 : " + num2);
		
		int result = num + 30;
		System.out.printf("num + 30 = %d\n", result);
		System.out.printf("result : %c\n", result);
		
	}

}
